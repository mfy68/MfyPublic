mfypublic介绍

1、什么是mfypublic?\
mfypublic是基于webdriver开发的一个功能扩展库，关于mfypublic最初在开发的时候，是根据webdriver进行的二次封装，简化代码。后续还会持续的扩展和开发一些新的功能，目前实现了以下功能：

对webdriver底层代码进行二次封装，改变了元素定位的方式\
获取日志\
读取excel数据\
读取json文件\
读取yaml文件


2、安装mfypublic\
mfypublic是基于python3.7开发的，安装前请确认你的python版本>3.7

安装命令\
pip install mfypublic